import warnings
warnings.filterwarnings("ignore", category=UserWarning)

from flask import Flask, request, jsonify, render_template
import pandas as pd
import joblib

app = Flask(__name__)

# ✅ Load all models
stack_model1 = joblib.load("model1.pkl")   # Biopsy
stack_model2 = joblib.load("model2.pkl")   # Citology
stack_model3 = joblib.load("model3.pkl")   # Schiller
stack_model4 = joblib.load("model4.pkl")   # Hinselmann

# Track conversation
user_state = {"step": 0, "features": {}}

# Questions
questions = [
    ("Smokes", "Do you smoke? (1 for Yes, 0 for No)"),
    ("Hormonal Contraceptives (years)", "How many years have you used hormonal contraceptives?"),
    ("STDs:HPV", "Do you have HPV? (1 for Yes, 0 for No)"),
    ("STDs", "Do you have any STDs? (1 for Yes, 0 for No)"),
    ("STDs: Number of diagnosis", "How many STD diagnoses have you had?"),
    ("STDs:condylomatosis", "Do you have condylomatosis? (1 for Yes, 0 for No)"),
    ("STDs:vulvo-perineal condylomatosis", "STD vulvo-perineal condylomatosis? (1 for Yes, 0 for No)"),
    ("STDs:genital herpes", "STD genital herpes? (1 for Yes, 0 for No)"),
    ("STDs:HIV", "HIV positive? (1 for Yes, 0 for No)"),
    ("STDs:syphilis", "STD syphilis? (1 for Yes, 0 for No)")
]

# Function to combine probabilities with weights
def combine_probabilities(probs, weights):
    total = sum(probs[m] * weights[m] for m in probs)
    total /= sum(weights.values())
    return total


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").strip()
    reply = ""

    if user_state["step"] == 0:
        reply = "Hello! I am your cervical cancer assistant. Let's start. " + questions[0][1]
        user_state["step"] = 1

    elif 1 <= user_state["step"] <= len(questions):
        key, q_text = questions[user_state["step"] - 1]

        try:
            value = float(user_message)
            user_state["features"][key] = value

            if user_state["step"] < len(questions):
                reply = questions[user_state["step"]][1]
                user_state["step"] += 1
            else:
                # ✅ All features collected
                df = pd.DataFrame([user_state["features"]])

                # Predictions for all 4 models
                probs = {
                    "Biopsy": stack_model1.predict_proba(df)[0, 1],
                    "Citology": stack_model2.predict_proba(df)[0, 1],
                    "Schiller": stack_model3.predict_proba(df)[0, 1],
                    "Hinselmann": stack_model4.predict_proba(df)[0, 1]
                }

                # Example weights (you can tweak these based on validation scores)
                # Example weights (literature based)
                weights = {
                    "Biopsy": 0.5,
                    "Citology": 0.2,
                    "Hinselmann": 0.2,
                    "Schiller": 0.1
                }

                final_prob = combine_probabilities(probs, weights)

                # 🎯 Risk categorization
                if final_prob < 0.33:
                    risk_zone = "🟢 Low Risk"
                elif final_prob < 0.66:
                    risk_zone = "🟡 Medium Risk"
                else:
                    risk_zone = "🔴 High Risk"

                # 💰 Approximate screening costs
                costs = {
                    "Biopsy": 350,
                    "Citology": 75,
                    "Hinselmann": 200,
                    "Schiller": 30
                }
                total_cost = sum(costs.values())

                reply = (
                    f"✅ Prediction complete!\n\n"
                    f"Biopsy: {probs['Biopsy']:.2f}\n"
                    f"Citology: {probs['Citology']:.2f}\n"
                    f"Hinselmann: {probs['Hinselmann']:.2f}\n"
                    f"Schiller: {probs['Schiller']:.2f}\n\n"
                    f"➡ Final combined probability of cervical cancer: {final_prob:.2f}\n"
                    f"➡ Risk Zone: {risk_zone}\n\n"
                    f"💰 Approximate Screening Costs (if all tests are done): ${total_cost}\n"
                    f"   - Biopsy: ${costs['Biopsy']}\n"
                    f"   - Cytology: ${costs['Citology']}\n"
                    f"   - Hinselmann: ${costs['Hinselmann']}\n"
                    f"   - Schiller: ${costs['Schiller']}\n"
                )



                # Reset for next session
                user_state["step"] = 0
                user_state["features"] = {}

        except ValueError:
            reply = "Please enter a number (like 1 or 0)."
        except Exception as e:
            reply = f"⚠️ Error: {str(e)}"
            user_state["step"] = 0
            user_state["features"] = {}

    return jsonify({"reply": reply})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)
