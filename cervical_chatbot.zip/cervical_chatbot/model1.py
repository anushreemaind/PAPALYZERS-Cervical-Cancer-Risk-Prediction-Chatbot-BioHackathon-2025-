import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.model_selection import StratifiedKFold

import csv
# Load dataset properly
df = pd.read_csv("cervical-cancer_csv.csv")

# Select only relevant columns
selected_df = df.loc[:, [
    'Smokes','Hormonal Contraceptives (years)','STDs:HPV','STDs','STDs: Number of diagnosis',
    'STDs:condylomatosis','STDs:vulvo-perineal condylomatosis','STDs:genital herpes',
    'STDs:HIV','STDs:syphilis','Hinselmann','Schiller','Citology','Biopsy'
]]
'''# Data cleaning
selected_df.describe()
selected_df.info()
selected_df.isnull().sum()'''


cleaned_df = selected_df.dropna()
cleaned_df.isnull().sum()
#cleaned_df.info()


features= cleaned_df.drop(columns=['Biopsy', 'Citology', 'Schiller','Hinselmann'])
biopsy_test = cleaned_df.loc[:,'Biopsy']
citology_test = cleaned_df.loc[:,'Citology']
schiller_test = cleaned_df.loc[:,'Schiller']
hinselmann_test = cleaned_df.loc[:,'Hinselmann']

from imblearn.over_sampling import SMOTE
import joblib
smote=SMOTE(sampling_strategy='minority', random_state = 5)
features,biopsy_test=smote.fit_resample(features,biopsy_test)
biopsy_test.value_counts()

x_train, x_test, y_train, y_test = train_test_split(features, biopsy_test, test_size=0.2, random_state=42)
knn= KNeighborsClassifier(weights = 'distance')
dt = DecisionTreeClassifier(class_weight='balanced')
rf = RandomForestClassifier(class_weight= 'balanced',random_state = 9)

lr = LogisticRegression(max_iter=1000)
c_space = [0.001, 0.01,0.1,1,10,100,1000]
param_grid = {'C': c_space}
lr_gs = GridSearchCV(lr, param_grid, cv=3, scoring = 'recall')

estimators = [ ('knn',knn),('dt', dt),('rf',rf)]
stack_model1 = StackingClassifier(estimators = estimators, final_estimator = lr_gs, cv=5)

stack_model1.fit(x_train,y_train)

y_test_probs = stack_model1.predict_proba(x_test)[:, 1]
y_train_probs = stack_model1.predict_proba(x_train)[:, 1]

from sklearn.metrics import precision_recall_curve

precision, recall, thresholds = precision_recall_curve(y_train, y_train_probs)

#print(precision)
#print(recall)

count = len(recall)-1

for y in reversed(recall):
  if y>=0.9:
    #print(thresholds[count])
    boundary = thresholds[count]
    #print(recall[count])
    #print(precision[count])
    break
  count-=1

y_test_pr = (y_test_probs >= boundary).astype(int)
y_train_pr = (y_train_probs >= boundary).astype(int)

# train

print('train Accuracy: ', accuracy_score(y_train, y_train_pr))
print('train Precision: ', precision_score(y_train, y_train_pr))
print('train Recall: ', recall_score(y_train, y_train_pr))
print('train F1 Score: ', f1_score(y_train, y_train_pr))

#test
print('test Accuracy: ', accuracy_score(y_test, y_test_pr))
print('test Precision: ', precision_score(y_test, y_test_pr))
print('test Recall: ', recall_score(y_test, y_test_pr))
print('test F1 Score: ', f1_score(y_test, y_test_pr))

confusion_matrix(y_test, y_test_pr)

CM = confusion_matrix(y_test,y_test_pr)
sns.heatmap(CM, annot=True, cmap='Blues', fmt='d')
plt.title("Annotated Heatmap")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

import joblib

# after training your model
joblib.dump(stack_model1, "model1.pkl")
print("✅ model1 saved as model1.pkl")


