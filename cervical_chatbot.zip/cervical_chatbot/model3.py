import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, precision_recall_curve
)
from imblearn.over_sampling import SMOTE
import seaborn as sns
import matplotlib.pyplot as plt
import joblib

# 1. Load dataset
df = pd.read_csv("cervical-cancer_csv.csv")
selected_df = df.loc[:, [
    'Smokes','Hormonal Contraceptives (years)','STDs:HPV','STDs','STDs: Number of diagnosis',
    'STDs:condylomatosis','STDs:vulvo-perineal condylomatosis','STDs:genital herpes',
    'STDs:HIV','STDs:syphilis','Hinselmann','Schiller','Citology','Biopsy'
]]
cleaned_df = selected_df.dropna().reset_index(drop=True)

# 2. Features & target = Schiller
X = cleaned_df.drop(columns=['Biopsy','Citology','Schiller','Hinselmann'])
y = cleaned_df['Schiller']

print("Class distribution before SMOTE:\n", y.value_counts())

# 3. Balance with SMOTE
smote = SMOTE(sampling_strategy='minority', random_state=3)
X, y = smote.fit_resample(X, y)

print("Class distribution after SMOTE:\n", y.value_counts())

# 4. Train/test split
x_train, x_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=50, stratify=y
)

# 5. Base models
knn = KNeighborsClassifier(weights='distance')
dt = DecisionTreeClassifier(class_weight='balanced')
rf = RandomForestClassifier(class_weight='balanced')

# 6. Tune Logistic Regression
lr = LogisticRegression(max_iter=1000, random_state=7)
param_grid = {'C': [0.01, 0.1, 1, 10]}
lr_gs = GridSearchCV(lr, param_grid, cv=3, scoring='recall')
lr_gs.fit(x_train, y_train)
best_lr = lr_gs.best_estimator_

# 7. Stacking model
estimators = [('knn', knn), ('dt', dt), ('rf', rf)]
stack_model3 = StackingClassifier(
    estimators=estimators, final_estimator=best_lr, cv=5
)
stack_model3.fit(x_train, y_train)

# 8. Threshold tuning
y_train_probs = stack_model3.predict_proba(x_train)[:, 1]
precision, recall, thresholds = precision_recall_curve(y_train, y_train_probs)
boundary = 0.5
for p, r, t in zip(precision[::-1], recall[::-1], thresholds[::-1]):
    if r >= 0.89:
        boundary = t
        break

# 9. Evaluate
y_test_probs = stack_model3.predict_proba(x_test)[:, 1]
y_test_pred = (y_test_probs >= boundary).astype(int)

print("\n--- Test Performance ---")
print("Accuracy :", accuracy_score(y_test, y_test_pred))
print("Precision:", precision_score(y_test, y_test_pred))
print("Recall   :", recall_score(y_test, y_test_pred))
print("F1 Score :", f1_score(y_test, y_test_pred))

# --- Confusion Matrix ---
cm = confusion_matrix(y_test, y_test_pred)
plt.figure(figsize=(6,4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["No Cancer","Cancer"],
            yticklabels=["No Cancer","Cancer"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix - Schiller (Model 3)")
plt.show()

# 10. Save model
joblib.dump(stack_model3, "model3.pkl")
print("✅ model3.pkl saved successfully!")


